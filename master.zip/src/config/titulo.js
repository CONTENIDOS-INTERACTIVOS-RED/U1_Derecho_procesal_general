module.exports = 'CIRED'
