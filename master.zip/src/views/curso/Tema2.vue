<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'2. Principios del Derecho Procesal'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden

    .bg-color-8.mb-5(data-aos="fade-up")
      .row.justify-content-center.align-items-center
        .col-lg
          .p-4
            p.mb-0(data-aos="fade-down") El Derecho Procesal, como rama instrumental del Derecho, se encuentra guiado por un conjunto de principios que constituyen su columna vertebral. Estos principios no son simples normas auxiliares, sino fundamentos esenciales que orientan, condicionan y regulan la totalidad del proceso judicial. Su finalidad es asegurar que toda actuación procesal se desarrolle dentro de un marco de justicia, transparencia, legalidad, imparcialidad y respeto por los derechos fundamentales.
        .col-lg-auto
          figure
            img(src='@/assets/curso/temas/29.png', alt='') 


    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/30.png", data-aos="zoom-in")                  
      .col-lg-8
        p(data-aos="fade-down") Comprender estos principios resulta indispensable para cualquier jurista, puesto que permiten interpretar correctamente las normas procesales, resolver vacíos normativos, prevenir arbitrariedades y garantizar que el proceso se mantenga como un medio eficaz y legítimo, para resolver los conflictos jurídicos.       
        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/31.svg")
            .col-lg.j1
              p.mb-0 En la práctica, los principios procesales no solo tienen una función orientadora, sino que también son aplicables directamente por jueces y abogados, incluso cuando no estén expresamente mencionados en las normas procesales.

    p(data-aos="fade-down") Estos principios se encuentran reconocidos en diferentes fuentes normativas del ordenamiento jurídico colombiano. Por un lado, existen principios generales del Derecho Procesal, que tienen un carácter supralegal y se derivan de los postulados constitucionales y del Estado Social de Derecho. Por otro lado, el Código General del Proceso Ley 1564 del 2012, en su Artículo 1 y siguientes, recoge los principios rectores del proceso civil, que también influyen en otros ámbitos, como el laboral, el administrativo o el penal, dada la naturaleza común de muchas de sus garantías (Chavarro Cadena, 2018).

    p(data-aos="fade-down") Entre los principios generales, se destacan: 

    .bg-full-width.bg-fondo-slider.mb-5(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Legalidad 
              p La legalidad, que exige que toda actuación procesal esté previamente establecida por la Ley.          
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/32.png")    

          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Debido proceso 
              p El debido proceso, que garantiza a todas las partes el derecho a ser oídas, a ofrecer y controvertir pruebas, y a obtener una decisión motivada; la igualdad de las partes, que impone al juez la obligación de tratar a los sujetos procesales en condiciones de equilibrio, sin privilegios o discriminaciones          
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/33.png") 

          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 Tutela judicial efectiva
              p La tutela judicial efectiva, que obliga al Estado a proporcionar mecanismos eficaces y accesibles para la protección de los derechos.          
            .col-lg-5
              figure
                img.img-a.img-t(src="@/assets/curso/temas/34.png")                                        

    p(data-aos="fade-down") Otros principios fundamentales son:

    .row.align-items-center.mb-5  
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/35.png", data-aos="zoom-in")               
      .col-lg-8
        .bg-color-7.p-2.j1(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/36.svg")
            .col-lg
              h5 Principio de contradicción
              p.mb-0 Reconoce el derecho de cada parte a conocer y rebatir los argumentos y pruebas de su contraparte. 
        .bg-color-7.p-2.j1.my-4(data-aos="fade-right")
          .row.align-items-center   
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/37.svg")
            .col-lg
              h5 Principio de imparcialidad
              p.mb-0 Principio de imparcialidad del juez, que exige que quien dirija el proceso no tenga intereses en el litigio ni actúe con prejuicio alguno.
        .bg-color-7.p-2.j1(data-aos="fade-left")
          .row.align-items-center        
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/38.svg")
            .col-lg
              h5 Principio de economía procesal
              p.mb-0 Que propende por una justicia célere, sencilla y eficaz, evitando trámites innecesarios o dilaciones injustificadas. 
  
    p(data-aos="fade-down") Desde la entrada en vigor del Código General del Proceso, se han fortalecido principios como:

    .bg-full-width-1.bg-fondo-1.py-4
      .px-4.px-md-5
        .row.justify-content-center.align-items-stretch.text-center.mb-4
          .col-lg-6.mb-4(data-aos="zoom-in-up")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/39.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center Principio de oralidad
                p.mb-0 Que busca dinamizar el proceso mediante audiencias públicas, con inmediación entre el juez y las partes, transparencia en la actuación y concentración de actos procesales. 
          .col-lg-6.mb-4(data-aos="zoom-in-down")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/30.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center Principio de lealtad procesal
                p.mb-0 Según el cual, las partes deben actuar de buena fe, sin dilatar indebidamente el proceso ni presentar pruebas o argumentos con fines engañosos. Estos principios se orientan a construir un proceso más justo, humano y eficiente.

    .row.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-3.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/11.svg")
            .col-lg
              p.mb-0 El estudio de los principios procesales, entonces, no es una tarea meramente teórica. Por el contrario, es una herramienta práctica que le permitirá, como operador jurídico, defender adecuadamente los intereses de su cliente, identificar vicios o irregularidades procesales, exigir el respeto por los derechos de las partes y contribuir al funcionamiento transparente y eficaz del sistema judicial colombiano. En definitiva, estos principios actúan como filtros normativos que permiten verificar que cada proceso se desarrolle dentro del marco constitucional y legal, y como garantía de que la justicia no sea solo un ideal, sino una realidad palpable en cada caso concreto.

      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/41.png", data-aos="zoom-in")

    #t_2_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.1] Principios generales del Derecho Procesal
    
    p(data-aos="fade-down") Los principios generales del Derecho Procesal constituyen la base normativa y ética que orienta el desarrollo de todo proceso judicial en un Estado de Derecho.

    .bg-full-width.bg-color-4.mb-5
      .px-4.p-md-5
        .row.justify-content-center.align-items-center 
          .col-lg-4.mb-3.mb-lg-0
            figure(data-aos="zoom-in")
              img(src='@/assets/curso/temas/9.png', alt='')                  
          .col-lg-8
            h2.mb-4(data-aos="flip-up") Principios generales del Derecho Procesal 
            p.mb-4(data-aos="fade-right") En el PDF #[b Principios generales del Derecho Procesal], se analizan conceptos claves como legalidad, contradicción, igualdad, economía y dispositivo, así como su aplicación práctica en distintos contextos jurídicos. Estos principios garantizan que las actuaciones procesales se desarrollen con equidad, transparencia y respeto a los derechos fundamentales de las partes.
            a.anexo.mb-4.bg-white.w-fit(:href="obtenerLink('/downloads/Anexo_2.pdf')" target="_blank")(data-aos="flip-up")
              .anexo__icono(:style="{'background-color': '#FCDFDB'}")
                img(src="@/assets/template/icono-pdf.svg")
              .anexo__texto
                p <strong>Anexo. </strong> Principios generales del Derecho Procesal 

    #t_2_2.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.2] Principios rectores del Código General del Proceso

    .bg-full-width.bg-color-7.mb-5(data-aos="fade-up")
      .px-4.p-md-3
        .row.justify-content-center.align-items-center 
          .col-lg-auto.mb-3.mb-lg-0
            figure(data-aos="zoom-in")
              img(src='@/assets/curso/temas/45.svg', alt='')                  
          .col
            p.mb-0(data-aos="fade-down") El Código General del Proceso, contenido en la Ley 1564 del 2012, introdujo una profunda transformación en la justicia civil, buscando hacerla más ágil, eficiente, transparente y cercana a las necesidades de la ciudadanía. 

    p(data-aos="fade-down") Para lograrlo, el legislador adoptó una serie de principios rectores que orientan toda la actuación procesal y que deben ser observados por los jueces, las partes y demás intervinientes en cada etapa del proceso. Estos principios no son meras directrices teóricas, sino que tienen fuerza normativa y su desconocimiento puede acarrear nulidades o sanciones disciplinarias, además de afectar el derecho al debido proceso (Correa Medina, 2018).

    p(data-aos="fade-down") Estudiemos algunos principios:

    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-4.mb-3.mb-lg-0  
        figure
          img.img-a.img-t(src="@/assets/curso/temas/42.png", alt="")    
      .col-lg-8
        AcordionA(tipo="b")
          .div(titulo="Oralidad")
            p A diferencia del sistema anterior, basado principalmente en documentos escritos y trámites extensos, el nuevo modelo procesal privilegia el uso de la palabra hablada como mecanismo para dinamizar las audiencias y reducir la duración del proceso. La oralidad no significa la exclusión de lo escrito, sino que la esencia del debate probatorio y argumentativo, debe concentrarse en las audiencias orales, donde el juez puede apreciar directamente la actuación de las partes y valorar, con mayor certeza, la prueba. Por ejemplo, en una audiencia inicial dentro de un proceso de restitución de inmueble arrendado, las partes deben presentar sus pretensiones, excepciones, acuerdos probatorios y solicitud de pruebas en presencia del juez, quien tomará decisiones inmediatas sobre su admisibilidad, evitando dilaciones innecesarias (Hernández Velasco, 2015).

          .div(titulo="Inmediación")
            p Este implica que el juez debe estar presente en las audiencias más importantes del proceso, especialmente en aquellas donde se practican pruebas. Esto garantiza que el juez tenga un conocimiento directo de los testimonios, los documentos y las actuaciones, lo que refuerza la imparcialidad y la calidad del juicio. Por ejemplo, si en una audiencia de instrucción se va a escuchar al testigo principal de un proceso por incumplimiento contractual, es el juez quien debe interrogarlo y observar su comportamiento, sin delegar esta función a un auxiliar. Así, la inmediación fortalece la convicción judicial sobre los hechos debatidos.

          .div(titulo="Concentración")
            p Busca que las actuaciones procesales se realicen en el menor número de diligencias posibles, evitando la fragmentación del proceso y favoreciendo decisiones oportunas. Bajo este principio, la audiencia inicial, la audiencia de instrucción y la audiencia de juicio se desarrollan sin largas interrupciones, y las decisiones del juez se toman dentro del mismo acto o en plazos breves. Por ejemplo, si en la audiencia inicial no se logra una conciliación, el juez debe resolver inmediatamente sobre las pruebas pedidas, fijar los hechos objeto de debate y programar la audiencia de instrucción. Esto permite que el proceso avance sin dilaciones que perjudiquen a las partes.

    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-8.mb-3.mb-lg-0  
        AcordionA(tipo="b")
          .div(titulo="Publicidad")
            p Garantiza que las actuaciones procesales sean accesibles a las partes y, en la mayoría de los casos, también al público en general. Este principio permite que cualquier interesado pueda asistir a las audiencias o consultar los expedientes, salvo que existan razones legales para limitar el acceso, como en procesos de familia o casos que comprometan la intimidad personal. Por ejemplo, en un proceso de responsabilidad médica, las audiencias serán públicas, salvo que se deban tratar temas confidenciales como historiales clínicos. La publicidad protege la transparencia judicial y refuerza la confianza ciudadana en el sistema de justicia.

          .div(titulo="Lealtad procesal")
            p Este exige que todas las partes actúen de buena fe, evitando comportamientos maliciosos, dilatorios o fraudulentos que desvirtúen la finalidad del proceso. La lealtad procesal implica que las pretensiones deben ser honestas, las pruebas deben aportarse con veracidad, y los recursos deben presentarse con base en razones jurídicas reales y no con ánimo de perjudicar al otro. Por ejemplo, si una parte presenta una solicitud de nulidad sabiendo que no hay fundamento legal, solo para retrasar el proceso, puede ser sancionada por temeridad o mala fe, conforme al Artículo 42 del Código General del Proceso (Correa Medina, 2018).                                    
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/43.png", alt="")      

    .row.justify-content-center.mb-5
      .col-lg-5.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/44.png", data-aos="zoom-in")              
      .col-lg-7 
        .bg-color-8.p-4.mb-4.j1(data-aos="fade-left")
          p.mb-0 Estos principios rectores se proyectan a lo largo de todo el procedimiento y permiten construir un proceso civil más coherente con los principios constitucionales del debido proceso, la eficiencia de la administración de justicia y la protección efectiva de los derechos. Su respeto y aplicación no solo garantizan el cumplimiento formal del proceso, sino que también aseguran que la justicia sea un servicio real, accesible y equitativo para todos los ciudadanos.
        p(data-aos="fade-down") Analicemos algunos ejemplos:


    .bg-full-width.bg-color-info.mb-5(data-aos="fade-right")
      .px-4.p-md-5
        .row.justify-content-center.align-items-center
          .col-lg-10
            ImagenInfografica.color-secundario
                template(v-slot:imagen)
                  figure
                    img(src='@/assets/curso/temas/46.svg', alt='', style="max-width: 1106px;").mx-auto

                .bg-color-white.box-shadow.p-3(x="2.5%" y="93%" numero="+")
                  h5 1. Acceso a la justicia
                  p Un copropietario de un bien inmueble interpone demanda de división de cosa común y accede a la jurisdicción, sin trabas ni demoras indebidas.
                .bg-color-white.box-shadow.p-3(x="15%" y="76%" numero="+")
                  h5 2. Oralidad y audiencias
                  p En un proceso de responsabilidad contractual, las partes exponen sus argumentos oralmente, ante el juez durante la audiencia inicial.
                .bg-color-white.box-shadow.p-3(x="25.1%" y="93%" numero="+")
                  h5 3. Igualdad de las partes
                  p En un proceso civil de pertenencia, el juez autoriza la intervención de un curador #[i ad litem] para proteger a una parte ausente o en estado de indefensión.
                .bg-color-white.box-shadow.p-3(x="38.5%" y="76%" numero="+")
                  h5 4. Concentración
                  p Durante una audiencia de declaratoria de pertenencia, el juez practica todas las pruebas y escucha alegatos sin interrupciones, garantizando agilidad y eficacia.
                .bg-color-white.box-shadow.p-3(x="50.9%" y="93%" numero="+")
                  h5 5. Inmediación 
                  p En un proceso ejecutivo por incumplimiento de obligación dineraria, el juez preside directamente la audiencia. 
                .bg-color-white.box-shadow.p-3(x="62.6%" y="76%" numero="+")
                  h5 6. Legalidad
                  p En una demanda por cumplimiento de contrato de compraventa, el juez fundamenta su fallo en el Código Civil, apoyado por doctrina y jurisprudencia de la Corte Suprema de Justicia.
                .bg-color-white.box-shadow.p-3(x="74.1%" y="93%" numero="+")
                  h5 7. Instancias 
                  p En un juicio de servidumbre, la parte que no está conforme con la sentencia de primera instancia presenta recurso de apelación ante el tribunal superior. 
                .bg-color-white.box-shadow.p-3(x="84.9%" y="76%" numero="+")
                  h5 8. Gratuidad
                  p Una persona demanda la nulidad de una cláusula contractual abusiva y no debe pagar por el acceso a la jurisdicción, aunque puede haber costas al finalizar el juicio por perder el proceso. 

    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="http://www.secretariasenado.gov.co/senado/basedoc/ley_1564_2012.html" target="_blank" rel="noopener noreferrer") Congreso de la Republica de Colombia (2012). Ley 1564 del 2012: Por medio de la cual se expide el Código General del Proceso y se dictan otras disposiciones. Diario Oficial. No. 48.489. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="http://www.scielo.org.co/scielo.php?script=sci_arttext&pid=S1692-25302016000200047" target="_blank" rel="noopener noreferrer") Estrada-Vélez, Sergio. (2016). Los principios generales del derecho en el artículo 230 de la Constitución Política. ¿Normas morales o normas jurídicas? Opinión Jurídica, 15(30), 47-66. 


            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.redalyc.org/pdf/3376/337630235007.pdf" target="_blank" rel="noopener noreferrer") Acosta Alvarado, P. A. (2010). Los principios generales del derecho y las normas tipo principio. Su conceptualización y uso en el ordenamiento internacional. Revista Derecho del Estado, (25), 193-219.  
            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.redalyc.org/pdf/3600/360033182005.pdf" target="_blank" rel="noopener noreferrer") Rueda Fonseca, M. D. (2005). La expedición de un Código general del proceso como mecanismo de descongestión: conveniencias y dificultades. ¿Responde la propuesta de código único a las exigencias de eficiencia de la justicia? Revista de Derecho Privado, (34), 123-137.  

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=5LhwJbMCP-U" target="_blank" rel="noopener noreferrer") rocio Archila. (2020). Derecho Procesal Civil l, clase 1.
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=wOm76n300CI" target="_blank" rel="noopener noreferrer") Revista de Cultura Filosófico - Jurídica. (2017). VICISITUDES DEL CÓDIGO GENERAL DEL PROCESO, Ramiro Bejarano.              

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema2',
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
