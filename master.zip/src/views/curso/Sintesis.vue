<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La unidad 1: El Derecho Sustancial y el Derecho Procesal. Los Principios del Derecho Procesal, establecen los fundamentos esenciales para comprender cómo se articulan los derechos reconocidos por la Ley con los mecanismos jurídicos que permiten hacerlos efectivos. A lo largo de esta unidad, se analiza la función instrumental del Derecho Procesal como garante de la justicia, su vinculación con los principios constitucionales y su rol en la protección de los derechos fundamentales. Este enfoque integral permite al estudiante fortalecer su comprensión del sistema procesal colombiano y adquirir herramientas claves para el análisis normativo, la interpretación jurídica y el ejercicio ético de la profesión legal.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
