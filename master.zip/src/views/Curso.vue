<template lang="pug">
#curso.curso
  router-view
</template>

<script>
export default {
  name: 'Curso',
}
</script>

<style lang="sass"></style>
