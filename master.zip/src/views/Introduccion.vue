<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .bg-full-width-1.bg-fondo-1
      .px-4.px-md-5.pb-md-3 
        .row.mb-5
          .col-lg-4.mb-3.mb-lg-0 
            figure
              img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")                  
          .col-lg-8
            .bg-color-1.p-4.mb-4(data-aos="fade-left")
              .row.align-items-start
                .col-lg-auto
                  img.img-a.img-t(src="@/assets/curso/temas/2.svg")
                .col-lg
                  p.mb-0 Comprender la diferencia entre el Derecho Sustancial y el Derecho Procesal, constituye un punto de partida esencial para el análisis jurídico y la interpretación normativa en contextos judiciales. Esta unidad aborda las características, finalidades y principios fundamentales del Derecho Procesal, permitiendo identificar su función como instrumento del Derecho Sustancial para la realización efectiva de la justicia. Se examina también la conexión entre el proceso y la Constitución Política, destacando el papel de los principios procesales como garantía del debido proceso y del acceso a una tutela judicial efectiva.

            p(data-aos="fade-down") Al finalizar la unidad, se espera que el estudiante evalúe críticamente las características y finalidades del Derecho Procesal, comprenda su estructura funcional y analice los principios rectores consagrados en el Código General del Proceso, así como su relación con los valores constitucionales que orientan el orden jurídico colombiano.

        .row
          .col-lg-8.mb-3.mb-lg-0 
            .bg-color-2.p-4.j1.mb-4(data-aos="fade-left")
              p.mb-0 La relevancia de esta temática radica en que sienta las bases conceptuales necesarias para el abordaje de materias procesales específicas, al tiempo que proporciona herramientas teóricas para la actuación profesional en el ámbito judicial y litigioso. Conocer los fundamentos del Derecho Procesal permite interpretar correctamente los procedimientos, identificar sus garantías y valorar su impacto en la protección de los derechos fundamentales.
          .col-lg-4
            figure
              img.img-a.img-t(src="@/assets/curso/temas/3.png", data-aos="zoom-in") 

        p(data-aos="fade-down") Esta unidad se desarrolla a partir de cuatro ejes temáticos:
        div.row.justify-content-center.align-items-stretch.text-center
          div.col-lg-3.mb-4(data-aos="zoom-in-up")
            div.bg-color-white.box-shadow.p-3.h-100.br-1
              img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/4.svg" alt="" style="width: 90px")
              h5 Eje temático 1
              p.mb-0 La diferenciación entre Derecho Sustancial y Derecho Procesal.
          div.col-lg-3.mb-4(data-aos="zoom-in-up")
            div.bg-color-white.box-shadow.p-3.h-100.br-1
              img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/5.svg" alt="" style="width: 90px")
              h5 Eje temático 2
              p.mb-0 El estudio de las características y finalidades del Derecho Procesal.
          div.col-lg-3.mb-4(data-aos="zoom-in-up")
            div.bg-color-white.box-shadow.p-3.h-100.br-1
              img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/6.svg" alt="" style="width: 90px")
              h5 Eje temático 3
              p.mb-0 El análisis de sus principios generales.
          div.col-lg-3.mb-4(data-aos="zoom-in-up")
            div.bg-color-white.box-shadow.p-3.h-100.br-1
              img.mx-auto.d-block.mb-4(src="@/assets/curso/temas/7.svg" alt="" style="width: 90px")
              h5 Eje temático 4
              p.mb-0 La revisión de los principios establecidos en el Código General del Proceso en conexión con la Constitución.

    .row
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/8.png", data-aos="zoom-in")              
      .col-lg-8 
        .bg-color-3.p-4.j1.h-100(data-aos="fade-left")
          p Se realizarán actividades de análisis normativo, ejercicios prácticos, foros de discusión y reflexiones escritas orientadas a fortalecer el pensamiento jurídico y argumentativo.

          p.mb-0 Se recomienda mantener una participación activa en las actividades propuestas, realizar una lectura atenta de la normatividad procesal vigente y reflexionar sobre la aplicación de estos conocimientos en contextos reales del ejercicio profesional. El desarrollo de esta unidad será clave para consolidar las bases del estudio del Derecho Procesal General y avanzar con solvencia en las unidades siguientes.

</template>
